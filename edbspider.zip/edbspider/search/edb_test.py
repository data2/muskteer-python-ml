import jieba
import jieba.posseg as psg
import string

# seg_list = jieba.cut("农林牧渔业民间固定资产投资_累计增长")  # 默认是精确模式
# print(",".join(seg_list))
#
# seg_list = jieba.cut_for_search("农林牧渔业民间固定资产投资_累计增长")  # 默认是精确模式
# print(",".join(seg_list))


print([(x.word,x.flag) for x in psg.cut("中国对圣多美和普林西比承包工程派出人数")])

list  = psg.cut("肉禽及其制品类农村居民消费价格指数(上月=100)")
count = 0
for word, flat in list:
    if count > 2:
        break
    if len(word) > 1 and "n" in flat:
        print("%s | %s" % (word, flat))
        count = count + 1
    if len(word) == 1 and "n" == flat:
        print("%s | %s" % (word, flat))
        count = count + 1


