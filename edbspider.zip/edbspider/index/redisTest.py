import redis

r = redis.Redis(host='localhost', port=6379, decode_responses=True)
# r.set("中国","A")
# print(r.get("中国"))
# r.set("中国", r.get("中国")+":"+"B")
# print(r.get("中国"))
# list = r.keys("*")
# print(list)
# print(r.get("人口"))
# print("--")
# print(r.get("运输"))
r.sadd("test","1")
r.sadd("test","2")

r.sadd("test","2")
print(r.smembers("test"))

r.close()

